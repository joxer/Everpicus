#include "pic24f.h"
#include "uart.h"
#include "monitor.h"
#include "diskio.h"
#include "ff.h"
#include "ffhelper.h"
#include "taskFlyport.h"
#include "grovelib.h"
#include "touch.h"
#include "httplib.h"
 
 
#define HOST "myhost"
#define SEND_LEN 96
#define USER "myuser"
#define PASSWORD "mypassword"
#define APIKEY "my apikey"
#define PROJECT "everpicus"


void FlyportTask()
{
	WFConnect(WF_DEFAULT);
	int timeout = 0;
	while ((WFStatus != CONNECTED) && timeout != 10){
		timeout++;
		vTaskDelay(50);
	}
	if(WFStatus != CONNECTED)
		WFStopConnecting();
	vTaskDelay(100);
	
	#ifdef INTERRUPT
	PR4 = 16000;
	T4CONbits.TON=1;
	_T4IE=1;
	T4CONbits.TCKPS0=0;
	T4CONbits.TCKPS1=0;
#endif
 
#if _USE_LFN
	Finfo.lfname = Lfname;
	Finfo.lfsize = sizeof(Lfname);
#endif

IOInit( p19, out);
	IOInit(p2, UART2RX);
        IOInit(p4, UART2TX);
		
		void *board = new(GroveNest);
	void *touch = new(Touch, TOUCH_ADDR0, 8);
 	attachToBoard(board, touch, I2C);
 	configure(touch);
 	int touchVar;
	
		UARTWrite(1, "Initializing SD card...\r\n");
	vTaskDelay(25);
 
	if ( f_mount(0, &Fatfs) == FR_OK)
		UARTWrite(1, "SD software module initialized!\r\n");
	else{	
		UARTWrite(1, "SD software module NOT initialized!\r\n");
		while(1){
			IOPut( 19,toggle);
			DelayMs(1000);
		}
	}
 
	disk_initialize(0);
	vTaskDelay(20);
	if (!disk_status(0))
	{
	        UARTWrite(1, "SD card initialized and ready!\r\n");
	}
	else{
		UARTWrite(1,"Error in initializing SD card\r\n");
 
		while(1){
		      IOPut( 19,toggle);
		      DelayMs(1000);
		}
	}
	
	  vTaskDelay(25);
	UARTWrite(1,"Flyport connected... hello world!\r\n");
 
	if(WFStatus == CONNECTED){
		UARTWrite(1,"connected, now transmitting old photos\n");
		vTaskDelay(75);
		IOPut( p19,on);
		unsigned char socket;
 
		int n = get_number_of_file_on_sd();
		if( n == 0){
			UARTWrite(1,"There aren't photos on SD card\n");
		}
		else{
			UARTWrite(1,"Found some photos\n");
		}
		while(n > 0){
			if(send_image() == 0)
				n-=1;
		}
	}
	
	  while (1)
	{
		UARTWrite(1,"Waiting for a photo\n");
		touchVar = get(touch); 
		if(touchVar & (PAD1))
		{
			UARTWrite(1, "Get new photo!\r\n");
			save_photo_to_sd();
			vTaskDelay(50);
			if(WFStatus == CONNECTED){
				send_image();
			}	
			vTaskDelay(50);
		}
		vTaskDelay(5);
	}
}

int send_image(){
	UARTWrite(1, "send photo!\r\
n");
	int num = get_last_file();		
	char namefile[14];
	sprintf(namefile,"image%d.jpeg",num);
	UARTWrite(1,namefile);
	
	   struct HTTP_HEADER_REQUEST pp;
	pp.resource = "/remote_update";
	pp.version = "HTTP/1.1";
	pp.host = HOST;
	pp.content_type = "application/x-www-form-urlencoded";
 
	TCP_SOCKET* socket = create_http_socket(HOST);
	if(socket == NULL)
		return -1;
	vTaskDelay(5);
	
		FIL info;
	f_open(&info,namefile,FA_READ);
	unsigned int wit,wit2;
	char* request = create_chunked_post(&pp);
	do_http_request(socket,request);
	free(request);
	char chunk_request_str[80];
	sprintf(chunk_request_str,"user=%s&password=%s&project=%s&apikey=%s&", USER, PASSWORD,PROJECT, APIKEY);
	char *chunked = get_chunked_text(chunk_request_str);
	do_http_request(socket, chunked);
	vTaskDelay(5);
	free(chunked);
	
	chunked = get_chunked_text("image=");
	do_http_request(socket, chunked);
 
	vTaskDelay(5);
	free(chunked);
	
	
	do{
		char* arg;				
		unsigned char sbuff[SEND_LEN];
		char xbuff[SEND_LEN*2+1];
		int i;
		f_read(&info,sbuff,SEND_LEN,&wit);	
 
		for(i = 0; i < SEND_LEN;i++){
			sprintf(&xbuff[i*2],"%02X",sbuff[i]);
		}
		xbuff[SEND_LEN*2+1] = '\0';
 
		arg = get_chunked_text(xbuff);
		do_http_request(socket,arg);
		vTaskDelay(20);					
		free(arg);
 
	}while(wit == SEND_LEN);
	
	
	end_chunked_request(socket);
	vTaskDelay(10);
	close_socket(socket);
	vTaskDelay(5);
 
	f_unlink(namefile);
	vTaskDelay(50);
	return 0;
}