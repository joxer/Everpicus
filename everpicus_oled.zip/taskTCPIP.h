// Size of the stack for TCP/IP stack
#define STACK_SIZE_TCPIP		(configMINIMAL_STACK_SIZE * 5)

//	TCP/IP task function prototype
void TCPIPTask();

